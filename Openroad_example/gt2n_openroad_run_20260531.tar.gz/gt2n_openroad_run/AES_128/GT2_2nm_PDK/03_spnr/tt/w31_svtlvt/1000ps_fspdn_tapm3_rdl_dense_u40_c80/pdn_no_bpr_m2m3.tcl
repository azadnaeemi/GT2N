# GT2N FSPDN PDN without global M1 stripes.
#
# The earlier tap-BPR experiment added full-height M1 PDN stripes so tap-cell
# M1 access pins could reach the frontside mesh.  That fixed OpenROAD PG
# connectivity but created real VDD/VSS shorts: full-height M1 stripes can pass
# over opposite-net tap access pins and the post-PDN V1 jogs then make those
# overlaps electrically visible to LVS.
#
# This PDN keeps the global mesh on M2/M3 and above.  The matching
# post_pdn_tap_to_m3.tcl script adds local M1->V1->M2->V2->M3 hookups from tap
# access pins into same-net M3 stripes, avoiding global same-layer M1 metal.

####################################
# global connections
####################################
# Create/connect canonical top-level PG nets even though the global mesh starts
# above the stdcell BPR/M1 access layers.
add_global_connection -net {VDD} -inst_pattern {.*} -pin_pattern {^(vdd|VDD|VPWR)$} -power
add_global_connection -net {VSS} -inst_pattern {.*} -pin_pattern {^(vss|VSS|VGND)$} -ground
global_connect

####################################
# voltage domain and mesh
####################################
set_voltage_domain -name {CORE} -power {VDD} -ground {VSS}
define_pdn_grid -name {grid} -voltage_domains {CORE} -pins {M9}

# Intentionally no BPR/followpin stripes and no global M1 stripes in OpenROAD.
# BPR is represented in the cell layouts, but OpenROAD/TritonRoute is not robust
# enough in this setup to route the backside stack directly.
add_pdn_stripe -grid {grid} -layer {M2} -width {0.012} -pitch {6.0} -offset {3.0}
add_pdn_stripe -grid {grid} -layer {M3} -width {0.014} -pitch {6.0} -offset {3.0} -extend_to_boundary
add_pdn_stripe -grid {grid} -layer {M4} -width {0.021} -pitch {8.0} -offset {4.0}
add_pdn_stripe -grid {grid} -layer {M5} -width {0.021} -pitch {8.0} -offset {4.0}
add_pdn_stripe -grid {grid} -layer {M6} -width {0.038} -pitch {16.0} -offset {8.0}
add_pdn_stripe -grid {grid} -layer {M7} -width {0.038} -pitch {16.0} -offset {8.0}
add_pdn_stripe -grid {grid} -layer {M8} -width {0.038} -pitch {24.0} -offset {12.0}
add_pdn_stripe -grid {grid} -layer {M9} -width {0.038} -pitch {24.0} -offset {12.0}

add_pdn_connect -grid {grid} -layers {M2 M3}
add_pdn_connect -grid {grid} -layers {M3 M4}
add_pdn_connect -grid {grid} -layers {M4 M5}
add_pdn_connect -grid {grid} -layers {M5 M6}
add_pdn_connect -grid {grid} -layers {M6 M7}
add_pdn_connect -grid {grid} -layers {M7 M8}
add_pdn_connect -grid {grid} -layers {M8 M9}
