#!/usr/bin/env bash

# Docker on this server can mount /home/naeemi3, but not every deeper path.
# Keep ORFS launched from the real checkout while mounting the handoff bundle
# through a parent directory the daemon can access.
export RUN_DIR_HOST="$(pwd -P)"
_proj_probe="$RUN_DIR_HOST"
while [[ "$_proj_probe" != "/" && ! -x "$_proj_probe/OpenROAD-flow-scripts/flow/util/docker_shell" ]]; do
  _proj_probe="$(dirname "$_proj_probe")"
done
if [[ ! -x "$_proj_probe/OpenROAD-flow-scripts/flow/util/docker_shell" ]]; then
  echo "Error: could not locate project root containing OpenROAD-flow-scripts from: $RUN_DIR_HOST" >&2
  return 1
fi
export PROJ="$_proj_probe"
export ORFS="$PROJ/OpenROAD-flow-scripts"
export OR_IMAGE="${OR_IMAGE:-docker.io/openroad/orfs:26Q2}"
PROJECT_HOST_ROOT="$PROJ"
if [[ "$RUN_DIR_HOST" == */handoff/gt2n_openroad_run/* || "$RUN_DIR_HOST" == */handoff/gt2n_openroad_runonly/* ]]; then
  PROJECT_HOST_ROOT="${RUN_DIR_HOST%%/AES_128/*}"
  if [[ "$PROJECT_HOST_ROOT" == /home/naeemi3/* ]]; then
    export ORFS_WORKSPACE_HOST="/home/naeemi3"
    _project_rel="${PROJECT_HOST_ROOT#/home/naeemi3/}"
    export CONTAINER_PROJ_IN_CONTAINER="/work/$_project_rel"
    for _gid in 65534 103493; do
      case " ${ORFS_EXTRA_GROUPS:-} " in
        *" $_gid "*) ;;
        *) export ORFS_EXTRA_GROUPS="${ORFS_EXTRA_GROUPS:+$ORFS_EXTRA_GROUPS }$_gid" ;;
      esac
    done
  else
    export ORFS_WORKSPACE_HOST="$PROJECT_HOST_ROOT"
    export CONTAINER_PROJ_IN_CONTAINER="/work"
  fi
else
  export ORFS_WORKSPACE_HOST="$PROJ"
  export CONTAINER_PROJ_IN_CONTAINER="/work"
fi
export ORFS_WORK_MOUNT_TARGET="/work"

if [[ ! -d "$ORFS" ]]; then
  echo "Error: ORFS directory not found: $ORFS" >&2
  echo "Set ORFS=/path/to/OpenROAD-flow-scripts or place this overlay at the project root." >&2
  return 1
fi
if [[ ! -f "$RUN_DIR_HOST/config.mk" ]]; then
  echo "Error: config.mk not found in current directory: $RUN_DIR_HOST" >&2
  return 1
fi
case "$RUN_DIR_HOST" in
  "$PROJECT_HOST_ROOT") RUN_DIR_REL="" ;;
  "$PROJECT_HOST_ROOT"/*) RUN_DIR_REL="${RUN_DIR_HOST#"$PROJECT_HOST_ROOT"/}" ;;
  *) echo "Error: current directory is outside project root: $PROJECT_HOST_ROOT" >&2; return 1 ;;
esac
if [[ -n "$RUN_DIR_REL" ]]; then
  export DESIGN_CONFIG_IN_CONTAINER="$CONTAINER_PROJ_IN_CONTAINER/$RUN_DIR_REL/config.mk"
  export WORK_HOME_IN_CONTAINER="$CONTAINER_PROJ_IN_CONTAINER/$RUN_DIR_REL/work"
else
  export DESIGN_CONFIG_IN_CONTAINER="$CONTAINER_PROJ_IN_CONTAINER/config.mk"
  export WORK_HOME_IN_CONTAINER="$CONTAINER_PROJ_IN_CONTAINER/work"
fi
mkdir -p "$RUN_DIR_HOST/work"
orfs() { ( cd "$PROJ" && "$ORFS/flow/util/docker_shell" "$@" ); }
orfs_make() { orfs "make -f /OpenROAD-flow-scripts/flow/Makefile DESIGN_CONFIG=$DESIGN_CONFIG_IN_CONTAINER WORK_HOME=$WORK_HOME_IN_CONTAINER CONTAINER_PROJ=$CONTAINER_PROJ_IN_CONTAINER $*"; }
orfs_check() { orfs "openroad -version && yosys -V && klayout -v"; }
echo "ORFS environment loaded."
echo "PROJ=$PROJ"
echo "ORFS=$ORFS"
echo "RUN_DIR_HOST=$RUN_DIR_HOST"
echo "ORFS_WORKSPACE_HOST=$ORFS_WORKSPACE_HOST"
echo "CONTAINER_PROJ_IN_CONTAINER=$CONTAINER_PROJ_IN_CONTAINER"
echo "ORFS_EXTRA_GROUPS=${ORFS_EXTRA_GROUPS:-}"
echo "DESIGN_CONFIG_IN_CONTAINER=$DESIGN_CONFIG_IN_CONTAINER"
echo "WORK_HOME_IN_CONTAINER=$WORK_HOME_IN_CONTAINER"
