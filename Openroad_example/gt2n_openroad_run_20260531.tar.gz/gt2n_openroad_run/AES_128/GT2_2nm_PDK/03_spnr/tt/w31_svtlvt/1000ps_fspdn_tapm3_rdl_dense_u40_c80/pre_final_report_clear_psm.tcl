# PSM marker categories persist in ODBs after previous PG checks.  If the next
# check is clean, OpenROAD does not clear old markers before writing error files,
# so remove them explicitly before final IR analysis.
set block [ord::get_db_block]
set cat [$block findMarkerCategory PSM]
if {$cat != "NULL" && $cat != ""} {
  puts "Clearing stale PSM marker category with [$cat getMarkerCount] markers"
  ::odb::dbMarkerCategory_destroy $cat
} else {
  puts "No stale PSM marker category found"
}
foreach net {VDD VSS} {
  file delete -force $::env(REPORTS_DIR)/${net}.rpt
  file delete -force $::env(REPORTS_DIR)/${net}_check.rpt
}
