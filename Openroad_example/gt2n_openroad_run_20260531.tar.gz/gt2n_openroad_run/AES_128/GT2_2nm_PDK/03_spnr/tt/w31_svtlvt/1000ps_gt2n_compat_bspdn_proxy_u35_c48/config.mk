# AES GT2N BSPDN-proxy compatibility-flow run.
#
# This run intentionally separates the OpenROAD router view from the final
# physical/signoff view. OpenROAD uses the known-good frontside routing proxy;
# scripts/make_bspdn_physical_gds.sh then materializes real backside PG geometry
# on BPR/BM*/BRDL layers in a separate GDS.

export RUN_DIR := $(patsubst %/,%,$(dir $(abspath $(lastword $(MAKEFILE_LIST)))))
export CONTAINER_PROJ ?= /work
export DESIGN_NAME = aes
export DESIGN_NICKNAME = aes_128
export VERILOG_FILES = $(sort $(wildcard $(CONTAINER_PROJ)/AES_128/GT2_2nm_PDK/01_rtl/top/*.v))
export SDC_FILE = $(RUN_DIR)/constraint.sdc
export CORE_UTILIZATION ?= 35
export NUM_CORES ?= 48

include $(RUN_DIR)/gt2n_compat_bspdn_proxy_common.mk
