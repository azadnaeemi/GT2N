#!/usr/bin/env bash
set -euo pipefail

cd "$(dirname "$0")"
export OR_IMAGE="${OR_IMAGE:-docker.io/openroad/orfs:26Q2}"
source ./source_orfs.sh

echo "[$(date)] clean_all"
orfs_make clean_all

echo "[$(date)] route: pure BSPDN router view, tapbspdn, no POST_PDN_TCL, 48 cores, 20 DRT iterations"
orfs_make route NUM_CORES=48 DETAILED_ROUTE_END_ITERATION=20 | tee route_pure_bspdn_c48_i20.log

echo "[$(date)] finish"
orfs_make finish NUM_CORES=48 | tee finish_pure_bspdn_c48.log

echo "[$(date)] materialize physical BSPDN GDS"
./make_bspdn_physical_gds.sh | tee make_pure_bspdn_physical_gds.log

echo "[$(date)] physical BSPDN DRC"
./run_bspdn_physical_drc.sh | tee drc_pure_bspdn_physical.log

echo "[$(date)] physical BSPDN signal-only LVS"
./run_bspdn_physical_lvs_signal.sh | tee lvs_pure_bspdn_physical_signal.log

echo "[$(date)] DONE"
