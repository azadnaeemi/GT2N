# AES BSPDN Proxy Run

This directory reproduces the GT2N AES backside-PDN proxy example. OpenROAD
routes the signal design using a stable router view, then a deterministic
postprocess step materializes backside/BPR/BM/BRDL power geometry in the final
physical GDS.

Run everything from this directory with:

```bash
./run_all.sh
```

## Script Summary

- `source_orfs.sh`: loads the ORFS Docker environment for this handoff package,
  including the mount path, container project root, and supplemental groups.
- `run_all.sh`: top-level reproducer. It runs `clean_all`, `route`, `finish`,
  physical BSPDN GDS materialization, KLayout DRC, and signal-only LVS.
- `run_pure_bspdn_openroad_full.sh`: explicit BSPDN launcher containing the same
  major sequence in a single BSPDN-named script.
- `make_bspdn_physical_gds.sh`: postprocesses the routed GDS and adds the
  deterministic physical backside PG grid.
- `run_bspdn_physical_drc.sh`: runs KLayout DRC on the physical BSPDN GDS.
- `run_bspdn_physical_lvs_signal.sh`: runs signal-only KLayout LVS on the
  physical BSPDN GDS.
- `pdn_bspdn_proxy_router_view.tcl`: router-view PDN stub. It avoids asking
  OpenROAD/TritonRoute to route true BPR/BM backside layers directly.
- `pre_final_report_clear_psm.tcl`: clears stale PDNSim markers and old VDD/VSS
  report files before final reporting.
- `tapcell_d28.tcl`: run-local tap insertion script that places the selected
  BSPDN tap cell every 28 sites.

## Notes

`finish` triggers the normal ORFS final reports, including OpenSTA timing and
OpenROAD/OpenSTA vectorless power reporting. The backside power grid in the
final GDS is generated after signal routing, so native IR-drop analysis over
the full physical BSPDN structure remains a limitation requiring further work.
