#!/usr/bin/env bash
set -euo pipefail

# Run signal-only LVS on the postprocessed physical BSPDN GDS.  This deliberately
# ignores PG pin mismatches; PG connectivity for the backside mesh is inspected
# through the physical DRC/connectivity view until native BPR/BSPDN support is
# available in OpenROAD.

# shellcheck disable=SC1091
source ./source_orfs.sh >/dev/null
RESULTS_DIR_IN_CONTAINER="$WORK_HOME_IN_CONTAINER/results/gt2n_compat_bspdn_proxy/aes_128/base"
OBJECTS_DIR_IN_CONTAINER="$WORK_HOME_IN_CONTAINER/objects/gt2n_compat_bspdn_proxy/aes_128/base"
PHYS_GDS="$RESULTS_DIR_IN_CONTAINER/6_final_bspdn_physical.gds"
ROUTED_DEF="$RESULTS_DIR_IN_CONTAINER/6_final.def"
CDL="$OBJECTS_DIR_IN_CONTAINER/6_final_concat.cdl"
REPORT="$RESULTS_DIR_IN_CONTAINER/6_lvs_bspdn_physical_signal.lvsdb"
DECK="$CONTAINER_PROJ_IN_CONTAINER/OpenROAD-flow-scripts/flow/platforms/gt2n_compat_bspdn_proxy/gt2n_compat_bspdn_proxy.lylvs"

# Build the concatenated CDL dependency without invoking LVS on the non-physical GDS.
orfs_make "$CDL"
orfs "test -f $PHYS_GDS && test -f $ROUTED_DEF && test -f $CDL && /OpenROAD-flow-scripts/flow/scripts/klayout.sh -b -rd in_gds=$PHYS_GDS -rd def_file=$ROUTED_DEF -rd cdl_file=$CDL -rd report_file=$REPORT -rd signal_only_lvs=1 -r $DECK"

echo "Wrote signal-only LVS database: $REPORT"
